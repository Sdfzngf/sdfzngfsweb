﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows;
using System.Windows.Forms;
namespace SMMGYFSZ.JBK.Rooms
{
    public class Menu
    {
        private int linshiheight = 0;
        public int linshiy = 0;
        public int fujiawidth = 0;
        public Objects.MENUS mENUS = new Objects.MENUS();
        public Objects.xuanzec xuanzec = new Objects.xuanzec();
        public void Start()
        {
            mENUS.Start(SMMGYFSZ.Properties.Resources.MenuBack, 0, 0, 720, 1280);
            xuanzec.Start(Properties.Resources.xuanzhec, -30, -30);
        }
        public void Draw(Graphics g)
        {
            mENUS.Draw(g);
            g.FillRectangle(new SolidBrush(Color.FromArgb(125, Color.Black)), 240, linshiy, 99+fujiawidth, linshiheight);
            g.DrawRectangle(new Pen(Color.Gold, 3), 240, linshiy, 99+fujiawidth, linshiheight);
            g.FillRectangle(new SolidBrush(Color.FromArgb(20, Color.White)), 245+fujiawidth, linshiy+8, 89, 24);
            g.DrawImage(Properties.Resources.SatartGame, 245+fujiawidth, linshiy+8);
            g.FillRectangle(new SolidBrush(Color.FromArgb(20, Color.White)), 245 + fujiawidth, linshiy + 120, 89, 24);
            g.DrawImage(Properties.Resources.tuituitui, 245 + fujiawidth, linshiy + 120);
            xuanzec.Draw(g);
            linshiheight += (170 - linshiheight) / 15;
            linshiy += (360 - linshiy) / 15;
        }
    }
}
