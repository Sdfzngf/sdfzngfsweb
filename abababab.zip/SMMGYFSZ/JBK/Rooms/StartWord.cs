﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace SMMGYFSZ.JBK.Rooms
{
    public class StartWord:Room
    {
        public void Draw(Graphics g)
        {
            g.DrawImage(Properties.Resources.thisitroom2rd, 0, 0, 1280, 720);
        }
    }
}
