﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace SMMGYFSZ.JBK.Objects
{
    public class YXObjects
    {
        public Bitmap Bitmap { get; set; }
        public float X { get; set; }
        public float Y { get; set; }
        public int Height { get; set; }
        public int Width { get; set; }
        public int Angle { get; set; }
        public void Start(Bitmap bitmap,int x=0,int y=0,int height=0,int width=0,int angle=0)
        {
            this.Bitmap= bitmap;
            this.X= x;
            this.Y= y;
            if (height != 0) { this.Height = height; } else { this.Height = Bitmap.Height; }
            if (width != 0) { this.Width = width; } else { this.Width = Bitmap.Width; }
            this.Angle= angle;
        }
        public void Draw(Graphics g)
        {
            g.DrawImage(Bitmap, X, Y, Width, Height);
        }
    }
}
