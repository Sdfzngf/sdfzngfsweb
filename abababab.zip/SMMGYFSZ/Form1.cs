﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMMGYFSZ
{
    public partial class Form1 : Form
    {
        public JBK.Rooms.Menu menu = new JBK.Rooms.Menu();
        private int MD = 0;
        private int roombh = 0;
        private JBK.Rooms.StartWord startWord = new JBK.Rooms.StartWord();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint, true);
            menu.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            e.Graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.Half;
            switch (roombh)
            {
                case 0:
                    menu.Draw(e.Graphics);
                    if ((Control.MousePosition.Y - this.Location.Y > menu.linshiy + 30) & (Control.MousePosition.Y - this.Location.Y < menu.linshiy + 60) & (Control.MousePosition.X - this.Location.X > 245) & (Control.MousePosition.X - this.Location.X < 344 + menu.fujiawidth))
                    {
                        menu.fujiawidth += (30 - menu.fujiawidth) / 5;
                        menu.xuanzec.X += (250 - menu.xuanzec.X) / 5;
                        menu.xuanzec.Y += (menu.linshiy - menu.xuanzec.Y + 8) / 5;
                        if (MD == 1)
                        {
                            roombh += 1;
                        }
                    }
                    else
                    if ((Control.MousePosition.Y - this.Location.Y > menu.linshiy + 150) & (Control.MousePosition.Y - this.Location.Y < menu.linshiy + 180) & (Control.MousePosition.X - this.Location.X > 245) & (Control.MousePosition.X - this.Location.X < 344 + menu.fujiawidth))
                    {
                        menu.fujiawidth += (30 - menu.fujiawidth) / 5;
                        menu.xuanzec.X += (250 - menu.xuanzec.X) / 5;
                        menu.xuanzec.Y += (menu.linshiy - menu.xuanzec.Y + 122) / 5;
                        if (MD == 1)
                        {
                            this.Close();
                        }
                    }
                    else
                    {
                        menu.fujiawidth += (0 - menu.fujiawidth) / 5;
                        menu.xuanzec.X += (-30 - menu.xuanzec.X) / 10;
                    }
                    break;
                case 1:
                    startWord.Draw(e.Graphics);
                    break;
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            MD = 1;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            MD = 0;
        }
    }
}
